import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: { main: "#6256B5", light: "#8B82D5", dark: "#433A91" },
    secondary: { main: "#B34B91" },
    background: { default: "#F5F2FB", paper: "#FFFFFF" },
    text: { primary: "#55558A", secondary: "#77758F" },
    warning: { main: "#B34B91" },
  },
  typography: {
    fontFamily: '"Roboto", "Arial", sans-serif',
    h5: { fontWeight: 700 },
    h6: { fontWeight: 700 },
    button: { textTransform: "none", fontWeight: 600 },
  },
  shape: { borderRadius: 10 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 8, minHeight: 42, boxShadow: "none" },
        containedPrimary: {
          background: "linear-gradient(100deg, #8D83E8 0%, #7065D4 100%)",
          "&:hover": { background: "linear-gradient(100deg, #7E74D9 0%, #6257C6 100%)", boxShadow: "none" },
        },
      },
    },
    MuiTextField: { defaultProps: { fullWidth: true, size: "small" } },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          backgroundColor: "rgba(255,255,255,.72)",
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: { minHeight: 42, fontSize: "0.78rem", fontWeight: 600, textTransform: "none" },
      },
    },
  },
});

export default theme;
