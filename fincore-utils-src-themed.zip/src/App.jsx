import { useState } from "react";
import { Box, Tabs, Tab, Typography } from "@mui/material";
import EncryptorDecryptor from "./components/EncryptorDecryptor";
import SmsUtility from "./components/SmsUtility";
import MailUtility from "./components/MailUtility";
import fincoreLogo from "./assets/Fincore_logo.svg";
import fincoreTitle from "./assets/Fincore_title.png";

const utilities = [
  { label: "Encrypt / Decrypt", component: <EncryptorDecryptor /> },
  { label: "SMS", component: <SmsUtility /> },
  { label: "Mail", component: <MailUtility /> },
];

export default function App() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <Box className="page-shell">
      <Box className="content-layout">
        <Box component="section" className="intro-panel">
          <Box className="brand">
            <img className="brand-symbol" src={fincoreLogo} alt="FinCore logo" />
            <img className="brand-name" src={fincoreTitle} alt="FinCore" />
          </Box>

          <Typography className="welcome-title">
            Welcome to FinCore Utilities
          </Typography>
          <Typography className="welcome-subtitle">
            Simple tools for everyday application support and development
          </Typography>
          <Typography className="intro-copy">
            Access common utilities from one place. Encrypt or decrypt text,
            test SMS delivery, and trigger template-based emails using the
            configured FinCore services.
          </Typography>

          <Box className="warning-section">
            <Typography className="warning-title">Important Notice</Typography>
            <ul>
              <li>This utility is intended for authorized users only.</li>
              <li>Use the correct environment before triggering SMS or email.</li>
              <li>All requests may be logged and monitored by the application.</li>
            </ul>
          </Box>
        </Box>

        <Box component="main" className="utility-panel">
          <Typography className="panel-eyebrow">DEVELOPER TOOLKIT</Typography>
          <Typography className="panel-title">Utilities</Typography>
          <Typography className="panel-description">
            Select a utility to get started.
          </Typography>

          <Tabs
            value={activeTab}
            onChange={(_, value) => setActiveTab(value)}
            variant="fullWidth"
            className="utility-tabs"
          >
            {utilities.map((item) => (
              <Tab key={item.label} label={item.label} />
            ))}
          </Tabs>

          <Box className="utility-content">
            {utilities[activeTab].component}
          </Box>
        </Box>
      </Box>

      <Box component="footer" className="page-footer">
        <span>FinCore Utilities</span>
        <span>For authorized use only</span>
      </Box>
    </Box>
  );
}
