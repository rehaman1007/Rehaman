import { Box, Typography } from "@mui/material";

export default function UtilityCard({ title, description, children }) {
  return (
    <Box className="utility-card">
      <Typography className="utility-card-title">{title}</Typography>
      {description && (
        <Typography className="utility-card-description">{description}</Typography>
      )}
      <Box className="utility-card-body">{children}</Box>
    </Box>
  );
}
