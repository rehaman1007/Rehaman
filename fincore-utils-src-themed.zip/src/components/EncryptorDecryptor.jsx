import { useState } from "react";
import { Button, MenuItem, Stack, TextField } from "@mui/material";
import UtilityCard from "./UtilityCard";
import { useSnackbar } from "../context/SnackbarContext";

async function deriveKey(password, salt) {
  const material = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 150000, hash: "SHA-256" },
    material, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]
  );
}
const encode = (value) => btoa(String.fromCharCode(...new Uint8Array(value)));
const decode = (value) => Uint8Array.from(atob(value), (char) => char.charCodeAt(0));

export default function EncryptorDecryptor() {
  const [mode, setMode] = useState("encrypt");
  const [input, setInput] = useState("");
  const [password, setPassword] = useState("");
  const [output, setOutput] = useState("");
  const { showSnackbar } = useSnackbar();

  const handleProcess = async () => {
    if (!input.trim() || !password) {
      showSnackbar("Enter text and password.", "warning");
      return;
    }

    try {
      if (mode === "encrypt") {
        const salt = crypto.getRandomValues(new Uint8Array(16));
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const key = await deriveKey(password, salt);
        const encrypted = await crypto.subtle.encrypt(
          { name: "AES-GCM", iv }, key, new TextEncoder().encode(input)
        );
        setOutput(`FC1:${encode(salt)}:${encode(iv)}:${encode(encrypted)}`);
      } else {
        const parts = input.split(":");
        if (parts.length !== 4 || parts[0] !== "FC1") {
          throw new Error("Invalid encrypted text format.");
        }
        const key = await deriveKey(password, decode(parts[1]));
        const decrypted = await crypto.subtle.decrypt(
          { name: "AES-GCM", iv: decode(parts[2]) }, key, decode(parts[3])
        );
        setOutput(new TextDecoder().decode(decrypted));
      }
      showSnackbar(mode === "encrypt" ? "Encryption successful." : "Decryption successful.", "success");
    } catch (error) {
      setOutput("");
      showSnackbar(error.message || "Unable to process the input.", "error");
    }
  };

  return (
    <UtilityCard
      title="Encryptor / Decryptor"
      description="Securely process text using password-based AES-256-GCM."
    >
      <Stack spacing={2}>
        <TextField select label="Operation" value={mode} onChange={(e) => { setMode(e.target.value); setOutput(""); }}>
          <MenuItem value="encrypt">Encrypt</MenuItem>
          <MenuItem value="decrypt">Decrypt</MenuItem>
        </TextField>
        <TextField
          label={mode === "encrypt" ? "Text to encrypt" : "Encrypted text"}
          multiline minRows={3} value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <TextField label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <Button variant="contained" onClick={handleProcess}>
          {mode === "encrypt" ? "Encrypt" : "Decrypt"}
        </Button>
        <TextField label="Output" multiline minRows={3} value={output} InputProps={{ readOnly: true }} />
        <Button disabled={!output} onClick={() => navigator.clipboard.writeText(output).then(() => showSnackbar("Copied.", "success"))}>
          Copy output
        </Button>
      </Stack>
    </UtilityCard>
  );
}
