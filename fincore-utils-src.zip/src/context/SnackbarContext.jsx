import { createContext, useContext, useState } from "react";
import { Alert, Snackbar } from "@mui/material";

const SnackbarContext = createContext(null);

export function SnackbarProvider({ children }) {
  const [notice, setNotice] = useState({ open: false, message: "", severity: "info" });

  const showSnackbar = (message, severity = "info") =>
    setNotice({ open: true, message, severity });

  const closeSnackbar = (_, reason) => {
    if (reason !== "clickaway") setNotice((current) => ({ ...current, open: false }));
  };

  return (
    <SnackbarContext.Provider value={{ showSnackbar }}>
      {children}
      <Snackbar
        open={notice.open}
        autoHideDuration={4000}
        onClose={closeSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert onClose={closeSnackbar} severity={notice.severity} variant="filled">
          {notice.message}
        </Alert>
      </Snackbar>
    </SnackbarContext.Provider>
  );
}

export function useSnackbar() {
  const context = useContext(SnackbarContext);
  if (!context) throw new Error("useSnackbar must be used inside SnackbarProvider");
  return context;
}
