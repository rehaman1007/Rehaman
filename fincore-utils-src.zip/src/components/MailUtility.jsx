import { useState } from "react";
import { Button, IconButton, Stack, TextField, Typography } from "@mui/material";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import UtilityCard from "./UtilityCard";
import api from "../api";
import { useSnackbar } from "../context/SnackbarContext";

export default function MailUtility() {
  const [recipientMail, setRecipientMail] = useState("");
  const [templateID, setTemplateID] = useState("");
  const [eventType, setEventType] = useState("MANUAL_TEST");
  const [placeHolders, setPlaceHolders] = useState([{ key: "", value: "" }]);
  const [loading, setLoading] = useState(false);
  const { showSnackbar } = useSnackbar();

  const updatePlaceholder = (index, field, value) =>
    setPlaceHolders((items) => items.map((item, i) => i === index ? { ...item, [field]: value } : item));

  const sendMail = async () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientMail)) return showSnackbar("Enter a valid recipient email.", "warning");
    if (!templateID.trim()) return showSnackbar("Enter a template ID.", "warning");
    const valid = placeHolders.filter((item) => item.key.trim() && item.value.trim());
    if (!valid.length) return showSnackbar("Add at least one complete placeholder.", "warning");
    if (new Set(valid.map((item) => item.key.trim())).size !== valid.length) return showSnackbar("Placeholder keys must be unique.", "warning");

    setLoading(true);
    try {
      await api.post(import.meta.env.VITE_MAIL_ENDPOINT || "/send-mail", {
        recipientMail, templateID, placeHolders: valid, eventType,
      });
      showSnackbar("Mail request submitted successfully.", "success");
      setRecipientMail("");
      setTemplateID("");
      setPlaceHolders([{ key: "", value: "" }]);
    } catch (error) {
      showSnackbar(error.response?.data?.message || "Failed to send mail.", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <UtilityCard title="Mail Utility" description="Trigger a template-based email with placeholder values.">
      <Stack spacing={2}>
        <TextField label="Recipient email" value={recipientMail} onChange={(e) => setRecipientMail(e.target.value)} />
        <TextField label="Template ID" value={templateID} onChange={(e) => setTemplateID(e.target.value)} />
        <TextField label="Event type" value={eventType} onChange={(e) => setEventType(e.target.value)} />
        <Typography fontWeight={600}>Template placeholders</Typography>
        {placeHolders.map((item, index) => (
          <Stack direction={{ xs: "column", sm: "row" }} spacing={1} key={index}>
            <TextField label="Key" value={item.key} onChange={(e) => updatePlaceholder(index, "key", e.target.value)} />
            <TextField label="Value" value={item.value} onChange={(e) => updatePlaceholder(index, "value", e.target.value)} />
            <IconButton aria-label="Remove placeholder" disabled={placeHolders.length === 1} onClick={() => setPlaceHolders((items) => items.filter((_, i) => i !== index))}><DeleteOutlineIcon /></IconButton>
          </Stack>
        ))}
        <Button onClick={() => setPlaceHolders((items) => [...items, { key: "", value: "" }])}>Add placeholder</Button>
        <Button variant="contained" onClick={sendMail} disabled={loading}>{loading ? "Sending..." : "Send mail"}</Button>
      </Stack>
    </UtilityCard>
  );
}
