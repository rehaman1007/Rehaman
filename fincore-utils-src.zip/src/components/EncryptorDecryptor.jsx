import { useState } from "react";
import { Box, Button, MenuItem, TextField, Stack } from "@mui/material";
import UtilityCard from "./UtilityCard";
import { useSnackbar } from "../context/SnackbarContext";

// Password-based AES-GCM encryption using the browser's Web Crypto API.
async function deriveKey(password, salt) {
  const material = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 150000, hash: "SHA-256" },
    material, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]
  );
}
const toBase64 = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes)));
const fromBase64 = (value) => Uint8Array.from(atob(value), (c) => c.charCodeAt(0));

export default function EncryptorDecryptor() {
  const [mode, setMode] = useState("encrypt");
  const [text, setText] = useState("");
  const [password, setPassword] = useState("");
  const [output, setOutput] = useState("");
  const { showSnackbar } = useSnackbar();

  const processText = async () => {
    if (!text.trim() || !password) {
      showSnackbar("Enter both text and password.", "warning");
      return;
    }
    try {
      if (mode === "encrypt") {
        const salt = crypto.getRandomValues(new Uint8Array(16));
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const key = await deriveKey(password, salt);
        const encrypted = await crypto.subtle.encrypt(
          { name: "AES-GCM", iv }, key, new TextEncoder().encode(text)
        );
        setOutput(`FC1:${toBase64(salt)}:${toBase64(iv)}:${toBase64(encrypted)}`);
      } else {
        const parts = text.split(":");
        if (parts.length !== 4 || parts[0] !== "FC1") throw new Error("Invalid encrypted text format.");
        const salt = fromBase64(parts[1]);
        const iv = fromBase64(parts[2]);
        const cipher = fromBase64(parts[3]);
        const key = await deriveKey(password, salt);
        const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, cipher);
        setOutput(new TextDecoder().decode(decrypted));
      }
      showSnackbar(mode === "encrypt" ? "Text encrypted." : "Text decrypted.", "success");
    } catch (error) {
      setOutput("");
      showSnackbar(error.message || "Unable to process text. Check the password.", "error");
    }
  };

  return (
    <UtilityCard title="Encryptor / Decryptor" description="Encrypt or decrypt text using password-based AES-256-GCM.">
      <Stack spacing={2}>
        <TextField select label="Operation" value={mode} onChange={(e) => { setMode(e.target.value); setOutput(""); }}>
          <MenuItem value="encrypt">Encrypt</MenuItem>
          <MenuItem value="decrypt">Decrypt</MenuItem>
        </TextField>
        <TextField label={mode === "encrypt" ? "Plain text" : "Encrypted text"} multiline minRows={4} value={text} onChange={(e) => setText(e.target.value)} />
        <TextField label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <Button variant="contained" onClick={processText}> {mode === "encrypt" ? "Encrypt" : "Decrypt"} </Button>
        <TextField label="Output" multiline minRows={4} value={output} InputProps={{ readOnly: true }} />
        <Box display="flex" justifyContent="flex-end">
          <Button disabled={!output} onClick={() => navigator.clipboard.writeText(output).then(() => showSnackbar("Copied to clipboard.", "success"))}>Copy output</Button>
        </Box>
      </Stack>
    </UtilityCard>
  );
}
