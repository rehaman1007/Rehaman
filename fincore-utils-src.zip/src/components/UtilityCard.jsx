import { Paper, Box, Typography } from "@mui/material";

export default function UtilityCard({ title, description, children }) {
  return (
    <Paper elevation={0} className="utility-card">
      <Box sx={{ mb: 2 }}>
        <Typography variant="h6" fontWeight={700}>{title}</Typography>
        {description && <Typography variant="body2" color="text.secondary">{description}</Typography>}
      </Box>
      {children}
    </Paper>
  );
}
