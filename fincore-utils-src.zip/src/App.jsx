import { useState } from "react";
import { Box, Tabs, Tab, Typography } from "@mui/material";
import EncryptorDecryptor from "./components/EncryptorDecryptor";
import SmsUtility from "./components/SmsUtility";
import MailUtility from "./components/MailUtility";

const utilities = [
  { label: "Encryptor / Decryptor", component: <EncryptorDecryptor /> },
  { label: "SMS Utility", component: <SmsUtility /> },
  { label: "Mail Utility", component: <MailUtility /> },
];

export default function App() {
  const [active, setActive] = useState(0);

  return (
    <Box className="app-shell">
      <Box className="side-panel">
        <img src="/Fincore_logo.svg" alt="FinCore" className="logo" />
        <img src="/Fincore_title.png" alt="FinCore Utilities" className="brand-title" />
        <Typography variant="body2" sx={{ mt: 2, lineHeight: 1.8 }}>
          A simple workspace for common FinCore developer utilities.
        </Typography>
        <Box className="side-divider" />
        <Typography variant="caption">DEVELOPER TOOLKIT</Typography>
      </Box>

      <Box className="main-panel">
        <Typography variant="h5" fontWeight={700} sx={{ mb: 2 }}>
          FinCore Utilities
        </Typography>
        <Tabs
          value={active}
          onChange={(_, value) => setActive(value)}
          variant="scrollable"
          scrollButtons="auto"
          sx={{ mb: 3 }}
        >
          {utilities.map((item) => <Tab key={item.label} label={item.label} />)}
        </Tabs>
        {utilities[active].component}
      </Box>
    </Box>
  );
}
