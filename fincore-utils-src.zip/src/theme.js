import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: { main: "#4A47A3", light: "#726FC3", dark: "#39347F" },
    secondary: { main: "#7354C7" },
    background: { default: "#F4F1FB", paper: "#FFFFFF" },
    text: { primary: "#35317A", secondary: "#65627A" },
  },
  typography: { fontFamily: "Roboto, Arial, sans-serif" },
  shape: { borderRadius: 12 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 9, textTransform: "none", fontWeight: 600, padding: "9px 18px" },
      },
    },
    MuiTextField: { defaultProps: { fullWidth: true, size: "small" } },
    MuiPaper: { styleOverrides: { rounded: { borderRadius: 14 } } },
  },
});

export default theme;
